# Prospect Licensing & Consulting — Design System

Version 0.2 — draft for approval
Prepared by PS Web Consulting

The source of truth for values is `brand.css`. This document explains the reasoning and the usage rules. Where the two disagree, the CSS wins.

**Scope:** a visual re-skin. Page structure, navigation, and all copy stay exactly as they are. Nothing in this system changes a word of text on the site.

---

## 1. The company

| | |
|---|---|
| Name | Prospect Licensing & Consulting Inc |
| Short mark | Prospect L&C |
| What they do | Truck permit licensing, registrations, fuel taxes and compliance consulting for trucking companies |
| Owner | Vessela Barzeva |
| Office | 605 E Algonquin Rd #230, Arlington Heights, IL 60005 |
| Phone | (847) 305-4339 |
| WhatsApp | 224-334-2227 |
| Email | support@prospectlc.com |
| Coverage | All 50 states, plus Canada permits |
| Platform | WordPress + Elementor |

**Proof points used across the site:** 50 states supported · 21 years of experience · 10,000+ permits processed.

**Service categories:** IRP registrations · IFTA and quarterly filings · state and hazmat permits · company formation (LLC, corp, EIN, MC, DOT, broker authority) · tax filings (2290, BOC-3, UCR) · miscellaneous (audits, SCAC, UIIA, bookkeeping, notary) · commercial truck insurance via partner.

**Affiliations:** Bulgarian Midwest Chamber of Commerce. Partners: RTS Financial, United Insurance Solutions.

### Audience

Owner-operators and small-to-midsize trucking company owners. Many are first-generation immigrant business owners. They are not shopping for design — they are worried about a deadline, a penalty, or a truck that cannot legally move.

### Voice

Calm, exact, deadline-aware. The site's job is to make a stressed operator feel that someone competent has this handled. Services are named the way the industry names them — IRP, IFTA, 2290, UCR, BOC-3 — because that is what the audience searches for.

---

## 2. Colour

### The palette

| Token | Hex | Role |
|---|---|---|
| `--brand-blue` | `#035F92` | The brand colour. Buttons, links, icons, active states, accented headlines |
| `--brand-white` | `#FFFFFF` | Primary surface |
| `--brand-ink` | `#121212` | All headings, h1 through h6 |
| `--grey-body` | `#565656` | Body copy — and nothing else |

Everything else in `brand.css` is derived from these four so tints and hover states are computed in one place rather than invented section by section.

**There is no green in this system.** The current sage CTA button becomes the brand blue. The WhatsApp button keeps its shape and its glyph but is styled in the system's own colours.

### Two rules that make a one-colour system work

**1. Blue is scarce.** Neutrals carry roughly 90% of every page — white surfaces, `#121212` headings, `#565656` body. Blue is reserved for action and emphasis: buttons, links, icons, the active nav item, dividers that separate content groups. `#E0F0FA` is the only tinted background, used to alternate bands so long service pages have rhythm; never two tinted bands in a row. `#01293F` is for the footer and at most one dark band per page. If a page looks blue, something that should have been neutral was coloured.

**2. Grey is body copy only.** `#565656` is a text colour with one job. It does not appear on headings, labels, captions, buttons, links, or borders, and it is not used as a surface. The other neutrals in `brand.css` are surface and border values only — never text. This is what keeps the page from drifting into the grey-on-grey look the current site has.

### Contrast — verified against WCAG 2.2 AA

| Pair | Ratio | Verdict |
|---|---|---|
| `#565656` on white | 7.3:1 | Passes AAA for body text |
| `#121212` on white | 18.7:1 | Passes everything |
| `#035F92` on white | 6.9:1 | Passes AA for all text |
| White on `#035F92` | 6.9:1 | Safe for filled buttons |
| `#565656` on `#F1F1F1` | 6.5:1 | Safe on grey surfaces |
| `#035F92` on `#E0F0FA` | 5.9:1 | Safe on the tinted band |

**Two prohibitions that follow from the maths:**

1. Never put `#035F92` text on `#121212` or on the dark footer — roughly 3:1, below the threshold for body text. On dark surfaces, headings go white and body goes `#BCDFF4`.
2. Never put `#565656` on any blue surface.

---

## 3. Typography

One type system for the entire site, hero included.

| Role | Family | Weight | Reasoning |
|---|---|---|---|
| h1–h3 | Playfair Display | 700 | The authority voice. High contrast, editorial, reads as established rather than startup |
| h4–h6 | Poppins | 600 | The functional voice. Sub-labels inside dense service content, where a display serif would be noise |
| Body | Georgia | 400 | A system serif. Nothing to load, excellent screen legibility at length, and it keeps the page in a serif register so the Playfair headings feel native rather than decorative |

### The scale

| Element | Size | Line height | Tracking |
|---|---|---|---|
| Hero headline | 44 → 72px fluid | 1.06 | −0.02em |
| h1 | 36 → 60px fluid | 1.12 | −0.015em |
| h2 | 30 → 44px fluid | 1.18 | −0.01em |
| h3 | 24 → 30px | 1.25 | −0.005em |
| h4 | 20px | 1.35 | 0 |
| h5 | 17px | 1.35 | 0 |
| h6 | 15px | 1.35 | 0 |
| Lead paragraph | 18 → 21px fluid | 1.55 | 0 |
| Body | 17px | 1.7 | 0 |
| Small / captions | 15px | 1.6 | 0 |
| Stat numerals | 40 → 60px fluid | 1.0 | −0.02em |

Body sits at 17px rather than 16 because Georgia's generous x-height reads slightly smaller than a sans at the same size, and gets 1.7 line height — more than a sans needs. Measure caps at 68ch; serif tolerates a longer line than sans, but not an unlimited one.

### Rules

- **The hero uses the same fonts as everything else.** Its headline is Playfair Display at the display size, its subheading is Georgia, its eyebrow and buttons are Poppins, and its stat numerals are Playfair. The hero is bigger than the rest of the site, not different from it.
- **Playfair is a display face.** Set at h1–h3 and nowhere smaller — its hairline strokes thin out and break up below about 22px.
- **Negative tracking on the serif headings, none on Poppins.** Playfair sets loose by default at large sizes.
- **The h3 → h4 break is a real change in voice**, from serif to sans. That is deliberate: h1–h3 are the page's argument, h4–h6 are labels inside content. Do not use an h4 where an h3 belongs just to get the sans.
- **Two weights maximum per family.** No Playfair italic in headings.
- **Self-hosted**, with Elementor's Google Fonts loading disabled. Preload Playfair 700 only — it is above the fold.

---

## 4. Shape and space

**Radius carries the personality here.** Taken from the approved hero: pill-shaped controls inside a single generously rounded container. The scale encodes hierarchy rather than putting one radius on everything.

| Token | Value | Applied to |
|---|---|---|
| `--radius-pill` | 999px | Every button, every chip |
| `--radius-xl` | 40px | Hero container and full-bleed feature panels |
| `--radius-lg` | 24px | Feature panels, the portrait card |
| `--radius-md` | 12px | Service cards, list panels, the map embed |
| `--radius-sm` | 6px | Form inputs |

Spacing runs on a 4px base. Section vertical rhythm is one fluid value (`--section-block`, 56 → 104px) so band spacing stays consistent across all 35 service pages without per-page adjustment.

**Elevation is restrained.** Depth comes from surface colour changes, not from a shadow under every card.

**Motion:** hover and focus transitions only, 120–200ms. `prefers-reduced-motion` zeroes all durations. No entrance animations on scroll.

---

## 5. Component set

Derived from what the site already contains — no new patterns, no removed ones.

| Component | Where it appears now |
|---|---|
| Header, sticky, with phone and CTA | Every page |
| Button — primary filled, secondary outline, WhatsApp | Throughout |
| Hero — full-bleed image, rounded container, stat row, portrait card | Home |
| Section band — white / tinted / inverse | Throughout |
| Service link list, grouped under a category heading | Home, Services |
| Service detail page template | ~35 pages |
| Dated notice card (registration and permit deadlines) | Home, Trucking Insights |
| Expandable "read more" panel | Trucking Insights |
| Review card with star rating | Home |
| Stat block | Home |
| Person card (portrait, name, role) | Home, About |
| Partner logo row | Home |
| Map embed panel | Home, Contact |
| Form — free consultation, contact | Contact, Free Consultation |
| Footer, four column, inverse surface | Every page |

**The one to get right is the service detail page template.** Thirty-five pages inherit it. Time spent there is worth more than time spent anywhere else on this project.

---

## 6. Implementation on WordPress

- Tokens load through the **child theme**, never Elementor's Custom CSS box
- Token values are mirrored into **Elementor Global Colors and Global Fonts** so the client's own editing controls stay usable:

| Elementor slot | Value |
|---|---|
| Primary | `#035F92` |
| Secondary | `#01293F` |
| Text | `#565656` |
| Accent | `#E0F0FA` |
| Primary font | Playfair Display |
| Secondary font | Poppins |
| Text font | Georgia |
| Accent font | Poppins |

- Elementor's **Google Fonts loading is disabled**; fonts are self-hosted
- The hero goes in as an HTML widget with the system's own markup; standard content sections stay native Elementor so the client can still edit them
- CSS uses `@layer tokens, base, components, utilities, overrides`. Plugin CSS lands unlayered and therefore wins by default, so it is wrapped into `overrides` deliberately rather than fought with `!important`
- Never Elementor Motion Effects and a JS animation library on the same element

**Fix during the re-skin:** the hero currently exists as three duplicate copies in the DOM for desktop, tablet and mobile. Collapse to one responsive section. This is a markup change only — the text stays identical.

### Quality floor

WCAG 2.2 AA. Visible focus not obscured by the sticky header. 44px minimum target size. One `h1` per page, no skipped heading levels. LCP under 2.0s, INP under 200ms, CLS under 0.1.

---

## 7. Open decision

**The WhatsApp glyph.** With green removed from the palette, the WhatsApp icon defaults to the brand blue like every other icon. The alternative is keeping the official green on that one glyph, as a platform mark rather than a brand colour — it is the one place green could be justified. Confirm which.
